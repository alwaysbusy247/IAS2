package Project;

import javax.swing.*;
import java.awt.event.*;

public class SecurityQuestionGUI extends JFrame {
    private JLabel lblQuestion;
    private JTextField txtAnswer;
    private JButton btnVerify;

    private String correctAnswer;

    public SecurityQuestionGUI(String question, String answer) {
        this.correctAnswer = answer.toLowerCase();
        setTitle("Security Verification");
        setSize(400, 180);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(null);

        lblQuestion = new JLabel("Security Question: " + question);
        lblQuestion.setBounds(30, 20, 340, 25);
        add(lblQuestion);

        txtAnswer = new JTextField();
        txtAnswer.setBounds(30, 60, 320, 25);
        add(txtAnswer);

        btnVerify = new JButton("Verify");
        btnVerify.setBounds(140, 100, 100, 30);
        add(btnVerify);

        btnVerify.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (txtAnswer.getText().trim().toLowerCase().equals(correctAnswer)) {
                    JOptionPane.showMessageDialog(null, "Security verification passed!");
                    dispose();
                    new PayrollGUI().setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "Incorrect answer. Access denied.");
                }
            }
        });
    }
}
