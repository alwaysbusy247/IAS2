package Project;

import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * Password utilities: PBKDF2 hashing, salt generation, random password generator.
 */
public class PasswordUtils {
    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String KDF_ALGO = "PBKDF2WithHmacSHA256";
    private static final int SALT_BYTES = 16;
    private static final int HASH_BYTES = 32; // 256 bits
    private static final int ITERATIONS = 100_000;

    public static String generateSaltBase64() {
        byte[] salt = new byte[SALT_BYTES];
        RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    public static String hashPasswordBase64(char[] password, byte[] salt) throws Exception {
        KeySpec spec = new PBEKeySpec(password, salt, ITERATIONS, HASH_BYTES * 8);
        SecretKeyFactory f = SecretKeyFactory.getInstance(KDF_ALGO);
        byte[] hashed = f.generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(hashed);
    }

    public static String hashPasswordBase64(String password, String saltBase64) throws Exception {
        byte[] salt = Base64.getDecoder().decode(saltBase64);
        return hashPasswordBase64(password.toCharArray(), salt);
    }

    public static boolean verifyPassword(String candidatePassword, String storedHashBase64, String saltBase64) {
        try {
            String candidateHash = hashPasswordBase64(candidatePassword, saltBase64);
            return constantTimeEquals(candidateHash.getBytes("UTF-8"), storedHashBase64.getBytes("UTF-8"));
        } catch (Exception ex) {
            return false;
        }
    }

    private static boolean constantTimeEquals(byte[] a, byte[] b) {
        if (a.length != b.length) return false;
        int result = 0;
        for (int i = 0; i < a.length; i++) result |= a[i] ^ b[i];
        return result == 0;
    }

    // generate a secure random password with letters, digits and symbols
    public static String generateRandomPassword(int length) {
        final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*()-_=+";
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int idx = RANDOM.nextInt(chars.length());
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }
}
