/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;

//import com.opencsv.CSVReader;
//import com.opencsv.CSVReaderBuilder;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.table.DefaultTableModel;

import com.opencsv.CSVWriter;

/**
 *
 * @author enuj
 */
public class Utils {
//    public static void main(String args[]) {
//        Object[][] d = GetData("10001");
//        System.out.println(d);
//    }
    public static boolean writeTableModelToCsv(DefaultTableModel tableModel, String filePath) {
        // Use try-with-resources to ensure writer is closed and proper CSV quoting
        try (CSVWriter writer = new CSVWriter(new FileWriter(filePath))) {
            // Write header
            String[] headers = new String[tableModel.getColumnCount()];
            for (int i = 0; i < headers.length; i++) {
                headers[i] = tableModel.getColumnName(i);
            }
            writer.writeNext(headers);

            // Write rows
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String[] rowData = new String[tableModel.getColumnCount()];
                for (int j = 0; j < rowData.length; j++) {
                    Object val = tableModel.getValueAt(i, j);
                    rowData[j] = val == null ? "" : val.toString();
                }
                writer.writeNext(rowData);
            }

            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static void writeLeaveToCsv(String[] data) {
        try (CSVWriter writer = new CSVWriter(new FileWriter("leaves.csv", true))) {
            writer.writeNext(data);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static String[] open_text(String empid)
    {
        // Use OpenCSV to correctly parse quoted fields and embedded commas
        try (com.opencsv.CSVReader reader = new com.opencsv.CSVReader(new FileReader(Config.DATA_FILE))) {
            String[] row;
            while ((row = reader.readNext()) != null) {
                if (row.length > 0 && row[0].equals(empid)) {
                    return row;
                }
            }
        } catch (Exception e) {
            System.out.print("File not found or error reading CSV: " + e.getMessage());
        }

        return null;
    }

    /**
     * Check whether credentials file contains an entry for the given username.
     */
    public static boolean credentialsContain(String username) {
        try (com.opencsv.CSVReader r = new com.opencsv.CSVReader(new FileReader("credentials.csv"))) {
            String[] rec;
            while ((rec = r.readNext()) != null) {
                if (rec.length > 0 && rec[0].equals(username)) return true;
            }
        } catch (Exception e) {
            // ignore
        }
        return false;
    }

    /**
     * Append a credentials row to credentials.csv using the new format:
     * username,hash_base64,salt_base64,role,question,answer
     * The passed password will be hashed using PBKDF2 and the salt stored.
     * Returns the plaintext password generated (or provided) so the caller can show it to admin.
     */
    public static String appendCredentialForUser(String username, String role, String question, String answer, String providedPassword) {
        try (CSVWriter w = new CSVWriter(new FileWriter("credentials.csv", true))) {
            String password = providedPassword == null ? PasswordUtils.generateRandomPassword(12) : providedPassword;
            String salt = PasswordUtils.generateSaltBase64();
            String hash = PasswordUtils.hashPasswordBase64(password, salt);
            String[] out = new String[] { username, hash, salt, role == null ? "EMP" : role, question == null ? "Set security question" : question, answer == null ? "" : answer };
            w.writeNext(out);
            return password;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    /**
     * Update an existing credentials row (used during migration) for the given username.
     * Rewrites the file in-place.
     */
    public static boolean updateCredentialRow(String username, String[] newRow) {
        try (com.opencsv.CSVReader r = new com.opencsv.CSVReader(new FileReader("credentials.csv"))) {
            java.util.List<String[]> all = r.readAll();
            boolean found = false;
            for (int i = 0; i < all.size(); i++) {
                String[] rec = all.get(i);
                if (rec.length > 0 && rec[0].equals(username)) {
                    all.set(i, newRow);
                    found = true;
                    break;
                }
            }
            if (!found) return false;
            try (CSVWriter w = new CSVWriter(new FileWriter("credentials.csv", false))) {
                for (String[] r2 : all) w.writeNext(r2);
            }
            return true;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
