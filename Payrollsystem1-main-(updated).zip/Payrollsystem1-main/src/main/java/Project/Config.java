package Project;

/**
 * Central configuration constants so CSV filename is consistent across the app.
 */
public final class Config {
    // change this value to switch which CSV file the app reads/writes
    public static final String DATA_FILE = "data.csv";

    private Config() {}
}
