/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Project;

/**
 *
 * @author enuj
 */
public class PayrollUtils {
    private String[] employee;
    private double totalHours = 48.0;
    private double basic;
    
    public PayrollUtils(String[] details){
        employee = details;
        // parse basic salary defensively: try index 13, otherwise search nearby or the first numeric-looking field
        basic = parseDoubleSafe(13, 0.0);
    }
    
    public double computePagibig(){
        if(basic <= 1500){
            return (basic * 0.01)/4;
        } else {
            return (basic * 0.02)/4;
        }
    }
    
    public double computeSss(){
        // check the beginning and return the rate
        if(basic < 3250){
            return 135/4;
        }

        // not in the beginning, check the end and return rate
        if(basic >= 24751){
            return 1125/4;
        }

        double rate = 157.5;
        double charge = 0;
        // not in the beginning and end, it must be inside
        // iterate every 500 then increase rate by 22.5 for every iteration
        for(double i = 3250; i < 24751; i += 500){
            // System.out.println(String.format("%s - %s = %s",i, i+500, rate));
            // for every iteration check salary range
            if(basic >= i && basic < i+500){
                // we're inside that means we satisfy the salary range
                // save the rate so we can return it, then exit the loop 
                charge = rate;
                break;
            }
            rate += 22.5;
        }
        // no explanation needed
        return charge/4;
    }
    
    public double computePhilhealth(){
        double base = (basic * 0.03) / 2;
        if(base <= 300){
            return 300/4;
        }else if(base >= 1800){
            return 1800/4;
        }else{
            return base/4;
        }
    }
    
    public double computeTax(){
        // Fixed tax rule: 3% of the period gross pay
        try {
            double gross = computeGross();
            return gross * 0.03;
        } catch (Exception e) {
            return 0.0;
        }
    }
    
    public double computePerks(){
        double rice = parseDoubleSafe(14, 0.0);
        double phone = parseDoubleSafe(15, 0.0);
        double clothing = parseDoubleSafe(16, 0.0);

        double total = rice + phone + clothing;

        return total / 4;
    }
    
    public double computeGross(){
        // Prefer hourly rate (usually last column). If missing, try gross semi-monthly rate and derive hourly rate.
        Double hourly = parseDoubleSafeNullable(18);
        if (hourly != null && hourly > 0) {
            return totalHours * hourly;
        }

        // try gross semi-monthly rate (index 17) and divide by (totalHours / 2) if necessary; but original logic expects hourly rate
        Double grossSemi = parseDoubleSafeNullable(17);
        if (grossSemi != null && grossSemi > 0) {
            // if grossSemi is semi-monthly, to get hourly approximate: (grossSemi * 2) / (totalHours * 2) -> grossSemi/totalHours
            return grossSemi;
        }

        // fallback: find last numeric value in the record and assume it's hourly rate
        for (int i = employee.length - 1; i >= 0; i--) {
            try {
                String s = employee[i].replaceAll(",", "").trim();
                if (s.isEmpty()) continue;
                double v = Double.parseDouble(s);
                // assume reasonable hourly rate
                if (v >= 0) {
                    return totalHours * v;
                }
            } catch (Exception ex) {
                // ignore and continue
            }
        }

        return 0.0;
    }
    
    public double computeTotalDeductions(){
        return computePagibig()+computePhilhealth()+computeSss()+computeTax();
    }
    
    public double computeNet(){
        return computeGross() - computeTotalDeductions();
    }
    
    // helpers
    private double parseDoubleSafe(int idx, double defaultVal) {
        Double d = parseDoubleSafeNullable(idx);
        return d == null ? defaultVal : d;
    }

    private Double parseDoubleSafeNullable(int idx) {
        if (employee == null) return null;
        // try exact index
        if (idx >= 0 && idx < employee.length) {
            try {
                String s = employee[idx].replaceAll(",", "").trim();
                if (!s.isEmpty()) return Double.parseDouble(s);
            } catch (Exception e) {
                // continue to scan
            }
        }

        // scan nearby indices (both directions)
        int maxOffset = 4;
        for (int offset = 1; offset <= maxOffset; offset++) {
            int i1 = idx - offset;
            int i2 = idx + offset;
            if (i1 >= 0 && i1 < employee.length) {
                try {
                    String s = employee[i1].replaceAll(",", "").trim();
                    if (!s.isEmpty()) return Double.parseDouble(s);
                } catch (Exception e) {}
            }
            if (i2 >= 0 && i2 < employee.length) {
                try {
                    String s = employee[i2].replaceAll(",", "").trim();
                    if (!s.isEmpty()) return Double.parseDouble(s);
                } catch (Exception e) {}
            }
        }

        // as last resort, scan entire array for any numeric-looking value
        for (int i = 0; i < employee.length; i++) {
            try {
                String s = employee[i].replaceAll(",", "").trim();
                if (s.isEmpty()) continue;
                return Double.parseDouble(s);
            } catch (Exception e) {}
        }

        return null;
    }

}
