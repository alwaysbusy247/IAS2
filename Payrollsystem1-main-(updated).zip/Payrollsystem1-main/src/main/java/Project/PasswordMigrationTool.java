package Project;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;

/**
 * Small CLI tool to replace legacy SHA-256 passwords that equal a known weak password
 * (for example "123") with new per-user PBKDF2 hashes and generated passwords.
 *
 * Usage (from project root):
 *  mvn -q -Dexec.mainClass="Project.PasswordMigrationTool" -Dexec.args="123" exec:java
 * Or run from IDE with a single argument: the legacy plaintext to search for (e.g. 123).
 */
public class PasswordMigrationTool {
    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.out.println("Usage: java Project.PasswordMigrationTool <legacyPlaintext>");
            System.exit(1);
        }
        String legacyPlain = args[0];
        System.out.println("Migrating credentials that match legacy plaintext: '" + legacyPlain + "'");

        // compute legacy hash
        String legacyHash;
        try {
            legacyHash = Hash256.toHexString(Hash256.getSHA(legacyPlain));
        } catch (NoSuchAlgorithmException ex) {
            System.err.println("SHA-256 unavailable: " + ex.getMessage());
            return;
        }

        Path credPath = Path.of("credentials.csv");
        if (!Files.exists(credPath)) {
            System.err.println("credentials.csv not found in working directory.");
            return;
        }

        List<String[]> all = new ArrayList<>();
        List<String> migrated = new ArrayList<>();

        try (CSVReader r = new CSVReader(new FileReader(credPath.toFile()))) {
            String[] rec;
            while ((rec = r.readNext()) != null) {
                if (rec.length >= 2 && rec[1].equalsIgnoreCase(legacyHash) && rec.length < 6) {
                    // legacy row and matches the weak password
                    String username = rec[0];
                    String role = rec.length > 2 ? rec[2] : "EMP";
                    String question = rec.length > 3 ? rec[3] : "Set security question";
                    String answer = rec.length > 4 ? rec[4] : "";

                    String newSalt = PasswordUtils.generateSaltBase64();
                    String newPassword = PasswordUtils.generateRandomPassword(12);
                    String newHash = PasswordUtils.hashPasswordBase64(newPassword, newSalt);

                    String[] newRow = new String[] { username, newHash, newSalt, role, question, answer };
                    all.add(newRow);
                    migrated.add(username + ":" + newPassword);
                    System.out.println("Migrated user " + username);
                } else {
                    all.add(rec);
                }
            }
        }

        if (migrated.isEmpty()) {
            System.out.println("No matching legacy accounts found to migrate.");
            return;
        }

        // write back credentials.csv (overwrite)
        try (CSVWriter w = new CSVWriter(new FileWriter(credPath.toFile(), false))) {
            for (String[] row : all) w.writeNext(row);
        }

        // write out generated passwords to a temporary file for admin
        Path out = Path.of("migrated-passwords.txt");
        Files.write(out, migrated);
        System.out.println("Migration complete. Generated passwords written to: " + out.toAbsolutePath());
        System.out.println("IMPORTANT: secure/delete that file after distributing passwords.");
    }
}
