package Project;

import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import com.opencsv.CSVReader;

import fi.iki.elonen.NanoHTTPD;

/**
 * Minimal embedded HTTP server to support local MFA approval PoC.
 * Endpoints:
 *  - GET /approve?sid={sid}  -> HTML form to enter ID+password and submit
 *  - POST /approve           -> form submit to verify credentials and approve session
 *  - GET /status?sid={sid}   -> returns plain text "pending" or "approved"
 */
public class MfaApprovalServer extends NanoHTTPD {
    private static MfaApprovalServer instance;
    private static final Map<String, Boolean> approved = new ConcurrentHashMap<>();

    public MfaApprovalServer(int port) throws IOException {
        super(port);
        start(NanoHTTPD.SOCKET_READ_TIMEOUT, false);
    }

    public static synchronized MfaApprovalServer startIfNeeded(int port) throws IOException {
        if (instance == null) {
            instance = new MfaApprovalServer(port);
        }
        return instance;
    }

    public static synchronized void stopIfRunning() {
        if (instance != null) {
            instance.stop();
            instance = null;
            approved.clear();
        }
    }

    public static void markApproved(String sid) {
        approved.put(sid, true);
    }

    /**
     * Ensure a session id exists in the approval map (pending=false).
     * Call this before showing the QR so the server is aware of the sid.
     */
    public static void ensureSession(String sid) {
        if (sid == null) return;
        approved.putIfAbsent(sid, false);
    }

    public static boolean isApproved(String sid) {
        return approved.getOrDefault(sid, false);
    }

    @Override
    public Response serve(IHTTPSession session) {
        String uri = session.getUri();
        Method method = session.getMethod();
        try {
            if ("/approve".equalsIgnoreCase(uri) && Method.GET.equals(method)) {
                // return HTML form
                String sid = session.getParms().get("sid");
                if (sid == null || sid.isEmpty()) {
                    sid = UUID.randomUUID().toString();
                    approved.put(sid, false);
                } else {
                    approved.putIfAbsent(sid, false);
                }
                String html = "<html><body>" +
                        "<h3>Mobile Approval Page</h3>" +
                        "<p>Enter your Employee ID and Password to approve this login.</p>" +
                        "<form method='post' action='/approve'>" +
                        "<input type='hidden' name='sid' value='" + sid + "'/>" +
                        "Employee ID: <input name='emp'/> <br/>" +
                        "Password: <input type='password' name='pwd'/> <br/>" +
                        "<input type='submit' value='Approve'/>" +
                        "</form></body></html>";
                return newFixedLengthResponse(Response.Status.OK, "text/html", html);
            } else if ("/approve".equalsIgnoreCase(uri) && Method.POST.equals(method)) {
                // parse body
                session.parseBody(new java.util.HashMap<>());
                Map<String, String> params = session.getParms();
                String sid = params.get("sid");
                String emp = params.get("emp");
                String pwd = params.get("pwd");
                System.out.println("[MfaApprovalServer] POST /approve from=" + session.getRemoteIpAddress() + " sid=" + sid + " emp=" + emp);
                if (sid == null || emp == null || pwd == null) {
                    return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "Missing parameters");
                }

                // verify credentials using credentials.csv
                boolean ok = verifyCredentials(emp.trim(), pwd);
                if (ok) {
                    approved.put(sid, true);
                    System.out.println("[MfaApprovalServer] session approved: " + sid);
                    String okHtml = "<html><body><h3>Approved</h3><p>You have successfully approved the login.</p></body></html>";
                    return newFixedLengthResponse(Response.Status.OK, "text/html", okHtml);
                } else {
                    String nok = "<html><body><h3>Denied</h3><p>Invalid credentials.</p></body></html>";
                    return newFixedLengthResponse(Response.Status.UNAUTHORIZED, "text/html", nok);
                }
            } else if ("/status".equalsIgnoreCase(uri) && Method.GET.equals(method)) {
                String sid = session.getParms().get("sid");
                System.out.println("[MfaApprovalServer] GET /status from=" + session.getRemoteIpAddress() + " sid=" + sid);
                if (sid == null) return newFixedLengthResponse(Response.Status.BAD_REQUEST, "text/plain", "missing sid");
                boolean a = approved.getOrDefault(sid, false);
                return newFixedLengthResponse(Response.Status.OK, "text/plain", a ? "approved" : "pending");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, "text/plain", "error: " + e.getMessage());
        }
        return newFixedLengthResponse(Response.Status.NOT_FOUND, "text/plain", "Not Found");
    }

    private boolean verifyCredentials(String empId, String password) {
        try (CSVReader csv = new CSVReader(new FileReader("credentials.csv"))) {
            String[] rec;
            while ((rec = csv.readNext()) != null) {
                if (rec.length == 0) continue;
                if (!rec[0].equals(empId)) continue;
                // new salted format: username,hash,salt,role,question,answer
                if (rec.length >= 6) {
                    String storedHash = rec[1];
                    String storedSalt = rec[2];
                    if (PasswordUtils.verifyPassword(password, storedHash, storedSalt)) return true;
                } else if (rec.length >= 2) {
                    // legacy SHA256
                    String hash = Hash256.toHexString(Hash256.getSHA(password));
                    if (rec[1].equalsIgnoreCase(hash)) {
                        // migrate: generate salt/hash and update the row
                        try {
                            String newSalt = PasswordUtils.generateSaltBase64();
                            String newHash = PasswordUtils.hashPasswordBase64(password, newSalt);
                            String role = rec.length > 2 ? rec[2] : "";
                            String q = rec.length > 3 ? rec[3] : "";
                            String a = rec.length > 4 ? rec[4] : "";
                            String[] newRow = new String[] { empId, newHash, newSalt, role, q, a };
                            Utils.updateCredentialRow(empId, newRow);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                        return true;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
